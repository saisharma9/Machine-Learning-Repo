# Assignment 2
This assignment is on the basic structures and functions of Python.

## Introduction
Open the Structures and Functions notebooks in the DS-Python repository _URL_ with Spyder.  Try running the chunks of code and then explore.  

## What to do
Modify the Assignment2 note book by adding in code sections to finish the tasks listed.
## Submission
### Process:  There are multiple parts to the assignment. You will insert a code section after each part where you will put your answer.
(You might also be asked to insert a MarkDown section as well.) 
### Commit and Push
Anytime you complete a part, you are required to commit to your local personalized copy of the repository. You will then push to the github repository.  Use good commit messages.  _Points will be deducted if you don't commit for each part._  Note:  It is always acceptable to make a change to a section later. Just remember to commit and push your work.
