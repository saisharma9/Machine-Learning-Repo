# Assignment 7
In this assignment you will explore Neural Nets.  To start, you will make and train some perceptrons.  Then you will use the FIFA data set from before and train Neural Nets on that data set.

## Introduction
Refer to the Neral Net slides.  Look at the note books in csis-machine-learning
1. MNIST 3layerNN

  

## What to do
Modify the Assignmenty note book by finishing the tasks listed in the code and mark down sections.
## Submission
### Process:  There are multiple parts to the assignment. Fill in the code and notes sections associated with each part.  You should not need to add in extra sections, but if you feel the need, do so.   
### Commit and Push
Anytime you complete a part, you are required to commit to your local personalized copy of the repository. You will then push to the github repository.  Use good commit messages.  _Points will be deducted if you don't commit for each part._  Note:  It is always acceptable to make a change to a section later. Just remember to commit and push your work.
