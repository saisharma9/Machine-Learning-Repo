# Data Acquiring

The dataset I have worked has been collected from Kaggle. The dataset has information of all the matches for seasons 2008 to 2019 of IPL (Indian Premier League). This dataset has good number of features like teams playing, toss decision , venue and others.

## Get the data here
https://www.kaggle.com/datasets/nowke9/ipldata?select=matches.csv


## Dataset in my project

[Dataset in my project](https://github.com/44-599-machine-learning-S22/project-machine-learning-s22-saisharma9/blob/main/matches.csv)