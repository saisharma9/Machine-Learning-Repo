# Machine-Learning-Project-Starter
Repository of all project documentation and Code

Topic: Indian Premier League 

***Description:*** This is a fantasy cricket league that happens in India among top cities every year during the month of April-May. My Goal is predict the match winners of match.

I am going to compare the factors for a team to win title like , toss desicion , toss winner , venue , teams.

## machine-learning-final-project
Github Link: https://github.com/44-599-machine-learning-S22/project-machine-learning-s22-saisharma9

## Links

- [RAW DATA](https://github.com/44-599-machine-learning-S22/project-machine-learning-s22-saisharma9/blob/main/Raw%20Data.md)

- [DATA](https://github.com/44-599-machine-learning-S22/project-machine-learning-s22-saisharma9/blob/main/Data.md)

- [ANALYSIS](https://github.com/44-599-machine-learning-S22/project-machine-learning-s22-saisharma9/blob/main/Analysis.md)

- [CONCLUSION](https://github.com/44-599-machine-learning-S22/project-machine-learning-s22-saisharma9/blob/main/Conclusion.md)


***DataSet*** :

https://www.kaggle.com/datasets/nowke9/ipldata?select=matches.csv

https://www.kaggle.com/datasets/nowke9/ipldata?select=deliveries.csv


### 1. initial_exploration notebook


I have read the data and cleaned unnecessary information from dataset. Later made sure no null values are present in dataset.




### 2. linear_regression notebook

I have created test and train sets for the model training and used features toss winner as X and targetted Winner. I used LabelEncoder to convert string values inti numeric. The Linear Regression model's accuracy score has been very low for this dataset and for the features I expected to be predictive , therefore looking forward to try new features and new models further.

### 3. classification notebook

Have changed the targetted values and found that Decision Tree model has got best accuracy among other models. This time have taken team1, team2 and venue of match and targetted the Winner to better accuracy, Also observed that Random Forest has similar accuracy for this data set.


### 4. Analysis notebook

In this stage of my project I have tried doing clustering and also did dimensional analysis.The visualizations of toss decision by toss winners and how successfull the decision was has been shown.


