# Data

1. This Dataset has 757 records and 14 columns
dtypes: int64(5), object(10)

2. Data from 2008 to 2019.

3. Made changes to make sure no null values in dataset.




### Features

1. Features in a cricket match were Date of match, city , team1,team2,toss_winner,toss_decision,winner, player_of_match,venue,umpires.

2. I choose toss_winner as X and targetted winner , expecting that toss winner could be the match winner but I have included more features like team1, team2, and venue in X to improve accuracy of model.

3. I have cleaned the data by removing unnecessary data like umpires information which would not be helpful in my predictions. There were teams which changed their names during these years and I have considered the current names and updated them throught datasets and for matches with no result due to rains the column values of winner,player_of_match is null so updated them with custom values "Draw/Cancelled".

[Intial Expolaration](https://github.com/44-599-machine-learning-S22/project-machine-learning-s22-saisharma9/blob/main/initial_exploration.ipynb)