# Conclusion

* There are many features which can be a important factor to predict a match winner , Initially I assumed to take only single feature which was toss winner.

* Apart from Toss winner , I have considered toss_decision , team1, team2 and venue to predict the winner.

* Majority of toss winners decision was to choose to field first.

* The toss decision of choosing field first has been pretty sucessfull.

* Decision Tree and Random forest performed best for this dataset.

Notebook Links:

[Initial Exploration](https://github.com/44-599-machine-learning-S22/project-machine-learning-s22-saisharma9/blob/main/initial_exploration.ipynb)


[Linear Regression](https://github.com/44-599-machine-learning-S22/project-machine-learning-s22-saisharma9/blob/main/linear_regression.ipynb)

[Classification Notebook](https://github.com/44-599-machine-learning-S22/project-machine-learning-s22-saisharma9/blob/main/classification.ipynb)

[Analysis Notebook](https://github.com/44-599-machine-learning-S22/project-machine-learning-s22-saisharma9/blob/main/analysis.ipynb)