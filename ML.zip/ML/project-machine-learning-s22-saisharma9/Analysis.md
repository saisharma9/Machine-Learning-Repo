# Analysis

### Linear Regression

* I have performed Liner Regression with just one feature for which the mean saquare error was high and accuracy score was very less (22%).

* Since my dataset output was not 0 or 1 , the linear regression model was not best fit for this dataset.

* For prediction where the results are in YES or NO just like mine where I want to see if the toss_winner will win or not Logistic regression is recomeneded.

[Logistic Regression Notebook](https://github.com/44-599-machine-learning-S22/project-machine-learning-s22-saisharma9/blob/main/linear_regression.ipynb)


### Classification

* The model score of Decision Tree and Random Forest is better and almost same.

* For Decision Tree, I got accuracy of 82% when I have included features team1,team2,venue targetting the winner.

* Have also did confusion matrix to obtain values of precision,Fscore and sensitivity.

[Classification Notebook](https://github.com/44-599-machine-learning-S22/project-machine-learning-s22-saisharma9/blob/main/classification.ipynb)


### Limitations

The major problem I encountered was that there were all the String values in my dataset initially . So before I apply modelling of dataset I have mapped the data to integer values using LabelEncoder.